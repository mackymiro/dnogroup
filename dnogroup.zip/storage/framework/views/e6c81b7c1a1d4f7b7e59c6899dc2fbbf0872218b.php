<?php $__env->startSection('content'); ?>
<script>
  $(document).ready(function(){
      $('.alert-success').fadeIn().delay(3000).fadeOut();
  });
</script>
<div id="wrapper">
	<ul class="sidebar navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="index.html">
          <i class="fas fa-cash-register"></i>
          <span>Sales Invoice</span>
        </a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
           <i class="fas fa-receipt"></i>
          <span>Delivery Receipt</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
          <a class="dropdown-item" href="<?php echo e(url('lolo-pinoy-lechon-de-cebu/delivery-receipt-form')); ?>">Delivery Receipt Form</a>
          <a class="dropdown-item" href="<?php echo e(url('lolo-pinoy-lechon-de-cebu/delivery-receipt/lists')); ?>">Lists</a>
         
        </div>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
           <i class="fab fa-first-order"></i>
          <span>Purchase order</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
          <?php if($user->role_type == 1): ?>
          <a class="dropdown-item" href="<?php echo e(url('lolo-pinoy-lechon-de-cebu/purchase-order')); ?>">P.O Form</a>
          <?php endif; ?>
          <a class="dropdown-item" href="<?php echo e(url('lolo-pinoy-lechon-de-cebu/purchase-order-lists')); ?>">Lists</a>
         
        </div>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
           <i class="fas fa-receipt"></i>
          <span>Statement of account</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
          <a class="dropdown-item" href="<?php echo e(url('lolo-pinoy-lechon-de-cebu/statement-of-account-form')); ?>">Statement of Account</a>
          <a class="dropdown-item" href="<?php echo e(url('lolo-pinoy-lechon-de-cebu/statement-of-account/lists')); ?>">Lists</a>
         
        </div>
      </li>
       <li class="nav-item dropdown active">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
           <i class="fas fa-receipt"></i>
          <span>Billing statement</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
          <?php if($user->role_type == 1): ?>
          <a class="dropdown-item" href="<?php echo e(url('lolo-pinoy-lechon-de-cebu/billing-statement-form')); ?>">Billing Statement Form</a>
          <?php endif; ?>
          <a class="dropdown-item" href="<?php echo e(url('lolo-pinoy-lechon-de-cebu/billing-statement-lists')); ?>">Lists</a>
         
        </div>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-file-invoice"></i>
          <span>Payment vouchers</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <a class="dropdown-item" href="<?php echo e(url('lolo-pinoy-lechon-de-cebu/payment-voucher-form')); ?>">Payment Voucher Form</a>
            <a class="dropdown-item" href="<?php echo e(url('lolo-pinoy-lechon-de-cebu/cash-vouchers')); ?>">Cash Vouchers</a>
            <a class="dropdown-item" href="<?php echo e(url('lolo-pinoy-lechon-de-cebu/cheque-vouchers')); ?>">Cheque Vouchers</a>  
        </div>
      </li>
     
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-apple-alt"></i>
          <span>Commissary</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
          
          <a class="dropdown-item" href="login.html">RAW materials</a>
          <a class="dropdown-item" href="register.html">Production</a>
          <a class="dropdown-item" href="<?php echo e(url('lolo-pinoy-lechon-de-cebu/commissary/stocks-inventory')); ?>">Stocks inventory</a>     
          <a class="dropdown-item" href="forgot-password.html">Delivery Outlets</a>

          <a class="dropdown-item" href="forgot-password.html">Sales of outlets</a>

          <a class="dropdown-item" href="forgot-password.html">Inventory of stocks</a>
         
        </div>
      </li>
     
     
    </ul>
    <div id="content-wrapper">
    	<div class="container-fluid">
    		 <!-- Breadcrumbs-->
              <ol class="breadcrumb">
                <li class="breadcrumb-item">
                  <a href="#">Lechon de Cebu</a>
                </li>
                <li class="breadcrumb-item active">Delivery Receipt All Lists</li>
              </ol>
              <div class="row">
              		<div class="col-lg-12">
          				<div class="card mb-3">
          						<div class="card-header">
		    					  <i class="fa fa-receipt" aria-hidden="true"></i>
		    					  All Lists</div>
	    					  	<div class="card-body">
                       <?php if(session('duplicateSuccess')): ?>
                       <p class="alert alert-success"><?php echo e(Session::get('duplicateSuccess')); ?></p>
                      <?php endif; ?> 
	    					  		<div class="table-responsive">
	    					  			<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
					  					<thead>
					  						<th>Action</th>
					  						<th>DR No</th>
	                      					<th>Date</th>
					  						<th>Sold To</th>
					  						<th>Time</th>
					  						<th>Delivered To</th>
					  						<th>Qty</th>
					  						<th>Description</th>
					  						<th>Price</th>
					  						<th>Created By</th>
				  						</thead>
			  							<tfoot>
				  							<th>Action</th>
					  						<th>DR No</th>
	                      					<th>Date</th>
					  						<th>Sold To</th>
					  						<th>Time</th>
					  						<th>Delivered To</th>
					  						<th>Qty</th>
					  						<th>Description</th>
					  						<th>Price</th>
					  						<th>Created By</th>

			  							</tfoot>
			  							<tbody>
			  								<?php $__currentLoopData = $getAllDeliveryReceipts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getAllDeliveryReceipt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			  								<tr id="deletedId<?php echo e($getAllDeliveryReceipt['id']); ?>">
			  									<td>
               						 <?php if($user->role_type !== 3): ?>
			  									<a href="<?php echo e(url('lolo-pinoy-lechon-de-cebu/edit-delivery-receipt/'.$getAllDeliveryReceipt['id'] )); ?>" title="Edit"><i class="fas fa-pencil-alt"></i></a>
               						 <?php endif; ?>
              						<?php if($user->role_type == 1): ?>
				  								<a id="delete" onClick="confirmDelete('<?php echo e($getAllDeliveryReceipt['id']); ?>')" href="javascript:void" title="Delete"><i class="fas fa-trash"></i></a>
              						<?php endif; ?>
				  								<a href="<?php echo e(url('lolo-pinoy-lechon-de-cebu/view-delivery-receipt/'.$getAllDeliveryReceipt['id'])); ?>" title="View"><i class="fas fa-low-vision"></i></a>
                          <?php if($user->role_type == 1): ?>
                            <?php if($getAllDeliveryReceipt['duplicate_status'] != 1): ?> 
                            <a href="<?php echo e(url('lolo-pinoy-lechon-de-cebu/duplicate-copy/'.$getAllDeliveryReceipt['id'])); ?>" title="Duplicate Copy"><i class="fas fa-clone"></i></a>
                            <?php endif; ?>
                          <?php endif; ?>
			  									</td>
			  									<td><?php echo e($getAllDeliveryReceipt['dr_no']); ?></td>
			  									<td><?php echo e($getAllDeliveryReceipt['date']); ?></td>
			  									<td><?php echo e($getAllDeliveryReceipt['sold_to']); ?></td>
			  									<td><?php echo e($getAllDeliveryReceipt['time']); ?></td>
			  									<td><?php echo e($getAllDeliveryReceipt['delivered_to']); ?></td>
			  									<td><?php echo e($getAllDeliveryReceipt['qty']); ?></td>
			  									<td><?php echo e($getAllDeliveryReceipt['description']); ?></td>
			  									<td><?php echo number_format($getAllDeliveryReceipt['price']);?></td>
			  									<td><?php echo e($getAllDeliveryReceipt['created_by']); ?></td>
			  									
			  								</tr>
			  								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			  							</tbody>
	    					  			</table>

	    					  		</div>
	    					  	</div>
          				</div>
              		</div>
              </div>
               <div class="row">
                    <div class="col-lg-12">
                        <div class="card mb-3">
                            <div class="card-header">
                              <i class="fa fa-receipt" aria-hidden="true"></i>
                              Duplicate Lists</div>
                            <div class="card-body">
                                <div class="table-responsive">
                                      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                            <thead>
                                              <th>Action</th>
                                              <th>DR No</th>
                                                        <th>Date</th>
                                              <th>Sold To</th>
                                              <th>Time</th>
                                              <th>Delivered To</th>
                                              <th>Qty</th>
                                              <th>Description</th>
                                              <th>Price</th>
                                              <th>Created By</th>
                                            </thead>
                                          <tfoot>
                                            <th>Action</th>
                                            <th>DR No</th>
                                                      <th>Date</th>
                                            <th>Sold To</th>
                                            <th>Time</th>
                                            <th>Delivered To</th>
                                            <th>Qty</th>
                                            <th>Description</th>
                                            <th>Price</th>
                                            <th>Created By</th>

                                          </tfoot>
                                          <tbody>
                                              <?php $__currentLoopData = $getDuplicateCopies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getDuplicateCopy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <tr>
                                                  <td>
                                                      <a href="<?php echo e(url('lolo-pinoy-lechon-de-cebu/view-delivery-duplicate/'.$getDuplicateCopy['id'])); ?>" title="View"><i class="fas fa-low-vision"></i></a>
                                                  </td>
                                                  <td><?php echo e($getDuplicateCopy['dr_no']); ?></td>
                                                  <td><?php echo e($getDuplicateCopy['date']); ?></td>
                                                  <td><?php echo e($getDuplicateCopy['sold_to']); ?></td>
                                                  <td><?php echo e($getDuplicateCopy['time']); ?></td>
                                                  <td><?php echo e($getDuplicateCopy['delivered_to']); ?></td>
                                                  <td><?php echo e($getDuplicateCopy['qty']); ?></td>
                                                  <td><?php echo e($getDuplicateCopy['description']); ?></td>
                                                  <td><?php echo number_format($getDuplicateCopy['price'], 2); ?></td>
                                                  <td><?php echo e($getDuplicateCopy['created_by']); ?></td>
                                              </tr>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </tbody>
                                      </table>
                                </div>
                            </div>
                        </div>
                    </div>
               </div>
    	</div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.4.1.js"></script>
<script type="text/javascript">
   function confirmDelete(id){
      var x = confirm("Do you want to delete this?");
        if(x){
            $.ajax({
              type: "DELETE",
              url: '/lolo-pinoy-lechon-de-cebu/delete-delivery-receipt/' + id,
              data:{
                _method: 'delete', 
                "_token": "<?php echo e(csrf_token()); ?>",
                "id": id
              },
              success: function(data){
                console.log(data);
                $("#deletedId"+id).fadeOut('slow');
               
              },
              error: function(data){
                console.log('Error:', data);
              }

            });

        }else{
            return false;
        }
   }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.lolo-pinoy-lechon-de-cebu-app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>