<?php $__env->startSection('content'); ?>
<div id="wrapper">
	<!-- Sidebar -->
    <ul class="sidebar navbar-nav">
       <li class="nav-item">
        <a class="nav-link" href="index.html">
          <i class="fas fa-cash-register"></i>
          <span>Sales Invoice</span>
        </a>
      </li>
     
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
           <i class="fab fa-first-order"></i>
          <span>Purchase order</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
          <?php if($user->role_type == 1): ?>
          <a class="dropdown-item" href="<?php echo e(url('lolo-pinoy-lechon-de-cebu/purchase-order')); ?>">P.O Form</a>
          <?php endif; ?>
          <a class="dropdown-item" href="<?php echo e(url('lolo-pinoy-lechon-de-cebu/purchase-order-lists')); ?>">Lists</a>
         
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="index.html">
          <i class="fas fa-receipt"></i>
          <span>Statement of account</span>
           <div class="dropdown-menu" aria-labelledby="pagesDropdown">
          <a class="dropdown-item" href="<?php echo e(url('lolo-pinoy-lechon-de-cebu/statement-of-account-form')); ?>">Statement of Account</a>
          <a class="dropdown-item" href="<?php echo e(url('lolo-pinoy-lechon-de-cebu/statement-of-account/lists')); ?>">Lists</a>
         
        </div>
        </a>
      </li>
       <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
           <i class="fas fa-receipt"></i>
          <span>Billing statement</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
          <?php if($user->role_type == 1): ?>
          <a class="dropdown-item" href="<?php echo e(url('lolo-pinoy-lechon-de-cebu/billing-statement-form')); ?>">Billing Statement Form</a>
          <?php endif; ?>
          <a class="dropdown-item" href="<?php echo e(url('lolo-pinoy-lechon-de-cebu/billing-statement-lists')); ?>">Lists</a>
         
        </div>
      </li>
     <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-file-invoice"></i>
          <span>Payment vouchers</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <a class="dropdown-item" href="<?php echo e(url('lolo-pinoy-lechon-de-cebu/payment-voucher-form')); ?>">Payment Voucher Form</a>
            <a class="dropdown-item" href="<?php echo e(url('lolo-pinoy-lechon-de-cebu/cash-vouchers')); ?>">Cash Vouchers</a>
            <a class="dropdown-item" href="<?php echo e(url('lolo-pinoy-lechon-de-cebu/cheque-vouchers')); ?>">Cheque Vouchers</a>  
        </div>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-apple-alt"></i>
          <span>Commissary</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
          
          <a class="dropdown-item" href="login.html">RAW materials</a>
          <a class="dropdown-item" href="register.html">Production</a>
          <a class="dropdown-item" href="forgot-password.html">Stocks inventory</a>     
          <a class="dropdown-item" href="forgot-password.html">Delivery Outlets</a>

          <a class="dropdown-item" href="forgot-password.html">Sales of outlets</a>

          <a class="dropdown-item" href="forgot-password.html">Inventory of stocks</a>
         
        </div>
      </li>
     
     
    </ul>
    <div id="content-wrapper">
    	<div class="container-fluid">
    		 <!-- Breadcrumbs-->
            <ol class="breadcrumb">
              <li class="breadcrumb-item">
                <a href="#">Lechon de Cebu</a>
              </li>
              <li class="breadcrumb-item active">View Purchase Order</li>
            </ol>
            <a href="<?php echo e(url('lolo-pinoy-lechon-de-cebu/purchase-order-lists')); ?>">Back to Lists</a>
             <div class="col-lg-12">
            	 <img src="<?php echo e(asset('images/lolo-pinoys-lechon-de-cebu.png')); ?>" width="366" height="178" class="img-responsive mx-auto d-block" alt="Lechon de Cebu">
            	 
            	 <h4 class="text-center"><u>VIEW PURCHASE ORDER</u></h4>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="card mb-3">
                        <div class="card-header">
                              <i class="fab fa-first-order" aria-hidden="true"></i>
                            View Purchase Order</div>
                        <div class="card-body">
                            <div class="form-group">
                                <div class="form-row">
                                  <div class="col-lg-6">
                                    <label>Paid to</label>
                                    <br>
                                   <?php echo e($purchaseOrder['paid_to']); ?>

                                  <br>
                                  <br>
                                  <label>Address</label>
                                  <br>
                                  Labogon Mandaue City
                                  
                                  </div>
                                  <div class="col-lg-6">
                                    <label>P.O Number</label>
                                    <br>
                                    <a href="#">P.O-<?php echo e($purchaseOrder['p_o_number']); ?></a>
                                    <br>
                                    <br>
                                    <label>Date</label>
                                    <br>
                                    <?php echo e($purchaseOrder['date']); ?>

                                  </div>
                                </div>
                               </div>
                               <table class="table table-striped">
                                  <thead>
                                    <tr>
                                      <th>QUANTITY</th>
                                      <th>DESCRIPTION</th>
                                      <th>UNIT PRICE</th>
                                      <th>AMOUNT</th>
                                    </tr>
                                  </thead>
                                    <tbody>

                                    <tr>
                                      <td><?php echo e($purchaseOrder['quantity']); ?></td>
                                      <td><?php echo e($purchaseOrder['description']); ?></td>
                                      <td><?php echo e($purchaseOrder['unit_price']); ?></td>
                                      <td><?php echo e($purchaseOrder['amount']); ?></td>
                                    </tr>
                                    <?php $__currentLoopData = $pOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pOrder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                      <td><?php echo e($pOrder['quantity']); ?></td>
                                      <td><?php echo e($pOrder['description']); ?></td>
                                      <td><?php echo e($pOrder['unit_price']); ?></td>
                                      <td><?php echo number_format($pOrder['amount'], 2) ?></td>
                                    </tr> 
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                      <td></td>
                                      <td></td>
                                      <td><strong>Total</strong></td>
                                      <td></td>
                                    </tr>
                                    </tbody>
                               </table>
                               <div class="form-group">
                                  <div class="form-row">
                                      <div class="col-lg-6">
                                        <label>Requested By</label>
                                      </div>
                                      <div class="col-lg-6">
                                        <label>Prepared By</label>
                                        <p><?php echo e($purchaseOrder['created_by']); ?></p>
                                      </div>
                                  </div>
                               </div>
                               <div class="form-group">
                                  <div class="form-row">
                                      <div class="col-lg-6">
                                        <label>Checked By</label>
                                      </div>
                                     
                                  </div>
                               </div>
                        </div>
                    </div>
                </div>
            </div>
             
    	</div>
    </div>	

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.lolo-pinoy-lechon-de-cebu-app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>