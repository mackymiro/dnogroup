<?php $__env->startSection('registerContent'); ?>
<style>
    .help-block{color:red;}
</style>
<div class="container" >
    <div class="card card-login mx-auto mt-5">
         <div class="card-header">Register an Account </div>
         <a style="text-align:center;" class="navbar-brand" href="<?php echo e(url('/')); ?>">
            <img src="<?php echo e(asset('images/ribos.jpg')); ?>" width="300" height="200" class="img-responsive" alt="Ribos Food Corporation">
        </a>
        <div class="card-body">
            <form class="form-horizontal" method="POST" action="<?php echo e(route('register')); ?>">
                 <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <div class="form-row">
                        <div class="col-md-6">
                            <div class="form-label-group<?php echo e($errors->has('firstName') ? ' has-error' : ''); ?>">
                                <input id="firstName" type="text" class="form-control" name="firstName" value="<?php echo e(old('firstName')); ?>" required autofocus>
                                <label for="firstName">First name</label>
                                 <?php if($errors->has('firstName')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('firstName')); ?></strong>
                                    </span>
                                <?php endif; ?>
                              </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-label-group<?php echo e($errors->has('lastName') ? ' has-error' : ''); ?>">
                               <input id="lastName" type="text" class="form-control" name="lastName" value="<?php echo e(old('lastName')); ?>" required autofocus>
                                <label for="lastName">Last name</label>
                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('lastName')); ?></strong>
                                    </span>
                                <?php endif; ?>
                              </div>
                        </div>
                    </div>
                </div>
                <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                  <div class="form-label-group">
                    <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>
                    <label for="inputEmail">Email address</label>
                    <?php if($errors->has('email')): ?>
                        <span class="alert alert-danger">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                    <?php endif; ?>
                  </div>
                </div>
                <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                  <div class="form-label-group">
                    <input id="password" type="password" class="form-control" name="password" value="" required>
                    <label for="inputPassword">Password</label>
                    <?php if($errors->has('password')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('password')); ?></strong>
                        </span>
                    <?php endif; ?>
                  </div>
                </div>
                <div class="form-label-group">
                    <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                    <label for="confirmPassword">Confirm password</label>
                </div>
                <br>
                <div class="form-label-group">
                    <select name="userType" class="form-control">
                        <option value="">--Please Select--</option>
                        <option value="1">Admin</option>
                        <option value="2">Sales</option>
                        <option value="3">User</option>
                    </select>
                    <?php if($errors->has('userType')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('userType')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <br>
                <button type="submit" class="btn btn-primary btn-block">
                    Register
                </button>
            </form>
             <div class="text-center">
            <a class="d-block small mt-3" href="<?php echo e(route('login')); ?>">Login Page</a>
            <a class="d-block small" href="<?php echo e(route('password.request')); ?>">Forgot Password?</a>
          </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<!--
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Register</div>

                <div class="panel-body">
                    <form class="form-horizontal" method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <label for="name" class="col-md-4 control-label">Name</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label for="email" class="col-md-4 control-label">E-Mail Address</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <label for="password" class="col-md-4 control-label">Password</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="password-confirm" class="col-md-4 control-label">Confirm Password</label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Register
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
-->
<?php echo $__env->make('layouts.register', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>